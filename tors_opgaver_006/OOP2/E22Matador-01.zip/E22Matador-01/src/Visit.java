public class Visit extends Field {
    public Visit(int ID, String label) {
        super(ID, label, 0, 0);
    }
}
