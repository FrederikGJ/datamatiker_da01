public class Plot extends Property  {

    public Plot(int ID, String label, int cost, int income, int seriesID){
        super(ID, label,cost, income, seriesID);
        this.seriesID = seriesID;
    }


}
